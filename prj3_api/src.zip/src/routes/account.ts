import express = require("express");
import controller = require("../controllers/account_controller");

const router = express.Router();
router.post('/register', controller.register);
router.get("/register/verify/:key", controller.verify);
router.post("/login", controller.login);

export const accountRoute = router;
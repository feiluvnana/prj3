import express = require("express");

export const res422 = (res: express.Response) => {
    res.status(422).json({
        code: '422 - Unprocessable Entity',
        message: 'Ohh you are missing some required parameters or providing invalid value, please read the API documentation to successfully register an account!'
    });
};

export const res404_noroute = (res: express.Response) => {
    res.status(404).json({
        code: '404 - Not Found',
        message: 'Ohh you are lost, please read the API documentation to find your way back home!'
    });
};

export const res404_nokey = (res: express.Response) => {
    res.status(404).json({
        code: '404 - Not Found',
        message: 'The system can\'t find your activation key. Maybe the key is expired or invalid!'
    });
};

export const res500 = (res: express.Response) => {
    res.status(500).json({
        code: '500 - Internal Server Error',
        message: 'Seems like something wrong happened, see you later!'
    });
};

export const res401_wronguserpass = (res: express.Response) => {
    res.status(401).json({
        code: '401 - Unauthorized',
        message: 'Your email or password is incorrect. Please try again!'
    });
};

export const res401_notactive = (res: express.Response) => {
    res.status(401).json({
        code: '401 - Unauthorized',
        message: 'Your account is not activated. Please activate your account first!'
    });
};

export const res200_duplicateemail = (res: express.Response) => {
    res.status(200).json({
        code: "200 - OK",
        message: "What a pity! This email was already registered!"
    });
}

export const res201_accountcreated = (res: express.Response) => {
    res.status(201).json({
        code: '201 - Created',
        message: 'An account has been created. Now it\'s time to activate it!'
    });
}

export const res201_accountactivated = (res: express.Response) => {
    res.status(200).json({
        code: '200 - OK',
        message: 'Congratulations! Your account has been activated!'
    });
}

export const res200_loggedin = (res: express.Response, token: string, expireAt: number) => {
    res.status(200).json({
        code: "200 - OK",
        message: "Yayy! Login successfully!",
        data: {
            token: token,
            expire_at: expireAt
        }
    });
}
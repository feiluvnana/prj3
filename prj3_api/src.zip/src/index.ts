import express = require('express');
import bodyParser = require('body-parser');

import norres = require('./views/view_template');
import { accountRoute } from './routes/account';

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
const port = 3802;

app.use("/account", accountRoute);

app.use((_, res) => {
    norres.res404_noroute(res);
});

app.listen(port, "localhost", () => {
    console.log(`Listening on port ${port}`)
});

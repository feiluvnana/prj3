import mysql = require('mysql2/promise');
const pool: mysql.Pool = require("../helpers/dbconfig").init();

export class ActivationKey {
    email: string;
    activationKey: string;
    expireAt: number;

    constructor(email: string, activationKey: string, expireAt: number) {
        this.email = email;
        this.activationKey = activationKey;
        this.expireAt = expireAt;
    }

    async create() {
        return pool.query(`INSERT INTO activation_key VALUE (?, ?, ?)`, [this.email, this.activationKey, this.expireAt])
            .then((_) => this)
            .catch((err) => err);
    }

    static async read(email: string) {
        return pool.query(`SELECT * FROM activation_key WHERE email = ? AND expire_at > ?`, [email, Date.now()])
            .then((value) => (value[0] as mysql.RowDataPacket[]).length == 0
                ? null
                : new ActivationKey(value[0]["email"], value[0]["activation_key"], value[0]["expire_at"]))
            .catch((err) => err);
    }
}
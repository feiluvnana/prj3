import mysql = require('mysql2/promise');
const pool: mysql.Pool = require("../helpers/dbconfig").init();

export class Account {
    email: string;
    password: string;
    active: boolean;

    constructor(email: string, password: string, active: boolean) {
        this.email = email;
        this.password = password;
        this.active = active;
    }

    async create() {
        return pool.query(`INSERT INTO account VALUE (?, ?)`, [this.email, this.password])
            .then(_ => this)
            .catch((err) => err);
    }

    static async read(email: string = "", password: string = "") {
        return pool.query(`SELECT * FROM account WHERE email = ? AND password = ?`, [email, password])
            .then(value => (value[0] as mysql.RowDataPacket[]).length == 0 
            ? null
            : new Account(value[0]["email"], value[0]["password"], value[0]["active"] == 1 ? true : false))
            .catch((err) => err);
    }

    async update(email: string) {
        return pool.query(`UPDATE account SET email = ?, password = ?, active = ? WHERE email = ?`, [this.email, this.password, this.active ? 1 : 0, email])
            .then(_ => this)
            .catch((err) => err);
    }

    async delete() {
        return pool.query(`DELETE FROM account WHERE email = ?`)
            .then(_ => null)
            .catch((err) => err);
    }
}
import mysql = require('mysql2/promise');
const pool: mysql.Pool = require("../helpers/dbconfig").init();

export class AuthenticationToken {
    email: string;
    authenticationToken: string;
    expireAt: number;

    constructor(email: string, activationKey: string, expireAt: number) {
        this.email = email;
        this.authenticationToken = activationKey;
        this.expireAt = expireAt;
    }

    async create() {
        return pool.query(`INSERT INTO authentication_token VALUE (?, ?, ?)`, [this.email, this.authenticationToken, this.expireAt])
            .then((_) => this)
            .catch((err) => err);
    }

    static async read(email: string) {
        return pool.query(`SELECT * FROM authentication_token WHERE email = ? AND expire_at > ?`, [email, Date.now()])
            .then((value) => (value[0] as mysql.RowDataPacket[]).length == 0
                ? null
                : new AuthenticationToken(value[0]["email"], value[0]["authentication_token"], value[0]["expire_at"]))
            .catch((err) => err);
    }
}
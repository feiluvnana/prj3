import express = require('express');
import regex = require('../helpers/regex');
import views = require('../views/view_template');
import crypto = require('crypto');
import mailerconfig = require('../helpers/mailerconfig');

import { Account } from '../models/account_model';
import { ActivationKey } from '../models/activation_key_model';
import { AuthenticationToken } from '../models/authentication_token_model';

export const register = async (req: express.Request, res: express.Response) => {
    const email = req.body["email"];
    const password = req.body["password"];
    if (email == null || password == null || !regex.email.test(email) || !regex.password.test(password)) {
        views.res422(res);
        return;
    }

    let result = await Account.read(email);
    if (!(result instanceof Account) && !(result === null)) {
        views.res500(res)
        return;
    } else if (result instanceof Account) {
        views.res200_duplicateemail(res);
        return;
    }

    let account = new Account(email, password, false);
    result = await account.create();
    if (!(result instanceof Account) && !(result === null)) {
        views.res500(res)
        return;
    }

    const seed = crypto.randomInt(1000000).toString().padStart(6, "0");
    const key = crypto.createHash('md5').update(email + seed).digest("hex");
    let activationKey = new ActivationKey(email, key, Date.now() + 600000);
    result = await activationKey.create();
    if (!(result instanceof Account) && !(result === null)) {
        views.res500(res)
        return;
    }

    mailerconfig.sendVerifyCode(email, `http://localhost:3802/register/verify/${activationKey}`)
    views.res201_accountcreated(res);
}

export const verify = async (req: express.Request, res: express.Response) => {
    const key = req.params.key;
    if (key == null || !regex.activation_key.test(key)) {
        views.res422(res);
        return;
    }

    let result = await ActivationKey.read(key);
    if (!(result instanceof ActivationKey) && !(result === null)) {
        views.res500(res)
        return;
    } else if (result === null) {
        views.res404_nokey(res);
        return;
    }

    result = await Account.read((result as ActivationKey).email);
    if (!(result instanceof Account) && !(result === null)) {
        views.res500(res)
        return;
    } else if (result === null) {
        views.res404_nokey(res);
        return;
    }

    let account = result as Account;
    account.active = true;
    result = await account.update(account.email);
    if (!(result instanceof Account) && !(result === null)) {
        views.res500(res);
        return;
    }
    views.res201_accountactivated(res);
}

export const login = async (req: express.Request, res: express.Response) => {
    const email = req.body.email;
    const password = req.body.password;
    if (email === null || password === null || !regex.email.test(email) || !regex.password.test(password)) {
        views.res422(res);
        return;
    }

    let result = await Account.read(email, crypto.createHash('md5').update(password).digest("hex"));
    if (!(result instanceof Account) && !(result === null)) {
        views.res500(res)
        return;
    } else if (result === null) {
        views.res401_wronguserpass(res);
        return;
    } else if (!(result as Account).active) {
        views.res401_notactive(res);
        return;
    }

    let account : Account = result as Account;

    result = await AuthenticationToken.read(email);
    if (!(result instanceof AuthenticationToken) && !(result === null)) {
        views.res500(res)
        return;
    } else if (result instanceof AuthenticationToken) {
        views.res200_loggedin(res, result.authenticationToken, result.expireAt);
        return;
    }


    let now = Date.now();
    let authenticationToken = new AuthenticationToken(account.email, crypto.createHash('sha1').update(account.email + now.toString()).digest("hex"),now + 1000 * 3600 * 24);
    result = authenticationToken.create();
    if (!(result instanceof AuthenticationToken) && !(result === null)) {
        views.res500(res);
        return;
    }

    views.res200_loggedin(res, authenticationToken.authenticationToken, authenticationToken.expireAt);
}


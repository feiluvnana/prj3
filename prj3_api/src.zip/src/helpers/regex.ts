export const password = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
export const email = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
export const activation_key = /^[a-fA-F0-9]{32}$/i